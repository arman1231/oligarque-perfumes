const list = document.querySelector(".container");
const addButton = document.querySelector(".addButton");
const removeButton = document.querySelector(".removeButton");
const el = document.querySelectorAll(".el");
const rootNodeInput = document.querySelector('[name="rootNode"]');
const columnCountInput = document.querySelector('[name="columnCount"]');
const elementGapInput = document.querySelector('[name="elementGap"]');

function stopDefAction(evt) {
  evt.preventDefault();
}
function renderWaterfall(rootNode, columnCount, elementGap) {
  rootNode.classList.add("grid");
  // rootNode.style.gridTemplate = `repeat(${columnCount}, 1fr) / repeat(${columnCount}, 1fr)`;
  rootNode.style.gridTemplateColumns = `repeat(${columnCount}, 1fr)`;
  rootNode.style.gap = `${elementGap}px`;
  el.forEach((element) => {
    element.style.color = "#fff";
    element.style.border = "1px solid red";

  });
}
addButton.addEventListener("click", (evt) => {
  stopDefAction(evt);
  renderWaterfall(list, columnCountInput.value, elementGapInput.value);
});
